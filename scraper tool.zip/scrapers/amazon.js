const puppeteer = require('puppeteer');

const columns = [
    "Style ID","Sku Id","ASIN","Title","Images","Videos","Description","Keywords","Bullet Points",
    "Attributes","Prime Tag","A+","B2B Price","Coupon","No of Ratings >10","Rating >=4",
    "OMS- Inventory Sync","Variants","All Points Checked","Sanitization Date","Remarks"
];

async function scrape(url) {
    const browser = await puppeteer.launch({headless: "new"});
    const page = await browser.newPage();
    await page.goto(url, {waitUntil: 'domcontentloaded'});

    let data = {};
    try {
        data["Style ID"] = "";
        data["Sku Id"] = "";
        const asinMatch = url.match(/\/([A-Z0-9]{10})(?:[/?]|$)/i);
        data["ASIN"] = asinMatch ? asinMatch[1] : "";
        data["Title"] = await page.$eval('#productTitle', el => el.innerText.trim());
        data["Images"] = (await page.$$eval('#altImages img', imgs => imgs.map(im=>im.src))).join(', ');
        data["Videos"] = (await page.$$eval('video source', vs => vs.map(v=>v.src))).join(', ');
        data["Description"] = await page.$eval('#productDescription', el => el.innerText.trim()).catch(()=> '');
        data["Keywords"] = "";
        data["Bullet Points"] = (await page.$$eval('#feature-bullets li:not(.aok-hidden)', lis=>lis.map(l=>l.innerText.trim()))).join(' | ');
        data["Attributes"] = (await page.$$eval('#productDetails_techSpec_section_1 tr', trs=>{
            return trs.map(tr=>{
                let th = tr.querySelector('th'), td = tr.querySelector('td');
                return th && td ? th.innerText.trim()+': '+td.innerText.trim() : '';
            }).join(' | ');
        })).replace(/\n/g,' ');
        data["Prime Tag"] = await page.$('.prime-logo') ? "Yes" : "No";
        data["A+"] = await page.$('.aplus-module') ? "Yes" : "No";
        data["B2B Price"] = "";
        data["Coupon"] = await page.$eval('.couponBadge', el => el.innerText.trim()).catch(()=> '');
        let rating = await page.$eval('.reviewCountTextLinkedHistogram.noUnderline', el=>el.getAttribute('title')).catch(()=> '');
        let ratingVal = rating ? parseFloat(rating.split(' ')[0]) : '';
        data["Rating >=4"] = ratingVal && ratingVal >=4 ? ratingVal : '';
        let numRatings = await page.$eval('#acrCustomerReviewText', el=>el.innerText.replace(/[^\d]/g,'')).catch(()=> '');
        data["No of Ratings >10"] = numRatings && parseInt(numRatings)>10 ? numRatings : '';
        data["OMS- Inventory Sync"] = "";
        data["Variants"] = (await page.$$eval('#twister .a-row', rows=>rows.map(r=>r.innerText.trim()))).join(' | ');
        data["All Points Checked"] = "";
        data["Sanitization Date"] = new Date().toISOString().slice(0,10);
        data["Remarks"] = "";
    } catch (e) {
        data["Remarks"] = "Scrape error: "+e.message;
    }
    await browser.close();

    columns.forEach(col=>{
        if(!data[col]) data[col]="";
    });
    return data;
}

module.exports = { scrape };