const puppeteer = require('puppeteer');

const columns = [
    "Style ID","Sku Id","ASIN","Title","Images","Videos","Description","Keywords","Bullet Points",
    "Attributes","Prime Tag","A+","B2B Price","Coupon","No of Ratings >10","Rating >=4",
    "OMS- Inventory Sync","Variants","All Points Checked","Sanitization Date","Remarks"
];

async function scrape(url) {
    const browser = await puppeteer.launch({headless: "new"});
    const page = await browser.newPage();
    await page.goto(url, {waitUntil: 'domcontentloaded'});

    let data = {};
    try {
        data["Style ID"] = "";
        data["Sku Id"] = "";
        data["ASIN"] = "";
        data["Title"] = await page.$eval('span.B_NuCI', el => el.innerText.trim()).catch(()=> '');
        data["Images"] = (await page.$$eval('img._396cs4', imgs => imgs.map(im=>im.src))).join(', ');
        data["Videos"] = "";
        data["Description"] = await page.$eval('div._1mXcCf', el => el.innerText.trim()).catch(()=> '');
        data["Keywords"] = "";
        data["Bullet Points"] = (await page.$$eval('div._2418kt ul li', lis=>lis.map(l=>l.innerText.trim()))).join(' | ');
        data["Attributes"] = (await page.$$eval('table._14cfVK tr', trs=>{
            return trs.map(tr=>{
                let tds = tr.querySelectorAll('td');
                return tds.length===2 ? tds[0].innerText.trim()+': '+tds[1].innerText.trim() : '';
            }).join(' | ');
        })).replace(/\n/g,' ');
        data["Prime Tag"] = "";
        data["A+"] = "";
        data["B2B Price"] = "";
        data["Coupon"] = await page.$eval('div._3Ay6Sb span', el => el.innerText.trim()).catch(()=> '');
        let ratingVal = await page.$eval('div._3LWZlK', el=>parseFloat(el.innerText)).catch(()=> '');
        data["Rating >=4"] = ratingVal && ratingVal >=4 ? ratingVal : '';
        let numRatings = await page.$eval('span._2_R_DZ', el=>el.innerText.replace(/[^\d]/g,'')).catch(()=> '');
        data["No of Ratings >10"] = numRatings && parseInt(numRatings)>10 ? numRatings : '';
        data["OMS- Inventory Sync"] = "";
        data["Variants"] = (await page.$$eval('div._3c7wqX', divs=>divs.map(d=>d.innerText.trim()))).join(' | ');
        data["All Points Checked"] = "";
        data["Sanitization Date"] = new Date().toISOString().slice(0,10);
        data["Remarks"] = "";
    } catch (e) {
        data["Remarks"] = "Scrape error: "+e.message;
    }
    await browser.close();

    columns.forEach(col=>{
        if(!data[col]) data[col]="";
    });
    return data;
}

module.exports = { scrape };