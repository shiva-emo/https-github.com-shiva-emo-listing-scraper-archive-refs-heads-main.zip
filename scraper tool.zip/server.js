const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const amazonScraper = require('./scrapers/amazon');
const flipkartScraper = require('./scrapers/flipkart');
const XLSX = require('xlsx');

const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json({limit: '10mb'}));

app.post('/api/scrape', async (req, res) => {
    let {urls, type} = req.body;
    if (!Array.isArray(urls) || !['amazon','flipkart'].includes(type)) {
        return res.status(400).json({error: 'Invalid input'});
    }
    const scraper = type==='amazon' ? amazonScraper : flipkartScraper;
    try {
        let results = [];
        for (let url of urls) {
            let data = await scraper.scrape(url);
            if (data) results.push(data);
        }
        res.json({results});
    } catch (e) {
        res.status(500).json({error: e.message});
    }
});

app.post('/api/excel', (req, res) => {
    const {type, data} = req.body;
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, type.charAt(0).toUpperCase()+type.slice(1));
    const fname = `${type}_listing_data.xlsx`;
    const buf = XLSX.write(wb, {type:'buffer', bookType:'xlsx'});
    res.setHeader('Content-Disposition', `attachment; filename=${fname}`);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.send(buf);
});

app.listen(PORT, () => {
    console.log(`Server running: http://localhost:${PORT}`);
});