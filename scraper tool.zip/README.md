# Amazon & Flipkart Listing Scraper

## Features
- Real data scraping (no fake data)
- Amazon & Flipkart support
- All required columns, images/videos direct links
- One folder, one command (`npm install && node server.js`)
- Local browser-based UI, download Excel in one click

## How to Use

1. Download and extract this folder anywhere.
2. Install Node.js (if not already).
3. Open terminal in this folder:
    ```
    npm install
    node server.js
    ```
4. Open browser: [http://localhost:3000](http://localhost:3000)
5. Paste product URLs, click buttons to fetch and download Excel.

**Note:**  
- Uses puppeteer (headless browser) for full, advanced data scraping.
- Speed depends on your internet and PC power.
- Always respects real site structure, no fake or random values.